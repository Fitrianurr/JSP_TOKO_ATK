/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tokoatk;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
/*
 *
 * @author F.Nurhayati
 */

public class SalesDetail {
    public Integer id;
    public String salesId;
    public String barangId;
    public Integer qty;
    public Integer harga;
    private Integer stok;
    
    public Integer getId() {
        return id;
    }
    
    public String getBarangId() {
        return barangId;
    }
            
    public String getBarangNama() {
        Barang barang = new Barang();
        barang.baca(barangId);
        return barang.getNama();
    }
            
    public Integer getQty() {
        return qty;
    }
        
    public Integer getHarga() {
        return harga;
    }
            
    public Integer getTotal() {
        return harga * qty;
    }
    
    public Integer getStok() {
        return stok;
    }
    
    public void setStok(Integer stok) {
        this.stok = stok;
    }
    
    
    public boolean tambah() {
        Connection conn = null;
        PreparedStatement st;
        try {
            conn = DbConnection.connect();
            // prepare insert statement
            String sql = "INSERT INTO salesd (salesId,barangId,qty,harga) values (?,?,?,?)";
            st = conn.prepareStatement(sql);
            st.setString(1, salesId);
            st.setString(2, barangId);
            st.setInt(3, qty);
            st.setInt(4, harga);
            st.executeUpdate();
            conn.close();
            
            return true;
        } catch (Exception ex) {
            if (conn != null) {
                try {
                    conn.close();
                } catch (Exception e) {
                    // Log error
                }
            }
            return false;
        }
    }
            
    public boolean baca(Integer id) {
        Connection conn = null;
        PreparedStatement st;
        ResultSet rs;
        try {
            conn = DbConnection.connect();
            // prepare select statement
            String sql = "SELECT * from salesd where id=?";
            st = conn.prepareStatement(sql);
            st.setInt(1, id);
            rs = st.executeQuery();
            boolean result = rs.next();
            if (result) {
                this.id = id;
                this.salesId = rs.getString("salesId");
                this.barangId = rs.getString("barangId");
                this.qty = rs.getInt("qty");
                this.harga = rs.getInt("harga");
            }
            conn.close();
            return result;
        } catch (Exception ex) {
            if (conn != null) {
                try {
                    conn.close();
                } catch (Exception e) {
                    // Log error
                }
            }
            return false;
        }
    }
            
    public boolean hapus() {
        Connection conn = null;
        PreparedStatement st;
        
        try {
            conn = DbConnection.connect();
            // prepare delete statement
            String sql = "DELETE FROM salesd where id=?";
            st = conn.prepareStatement(sql);
            st.setInt(1, id);
            st.executeUpdate();
            conn.close();
            return true;
        } catch (Exception ex) {
            if (conn != null) {
                try {
                    conn.close();
                } catch (Exception e) {
                    // Log error
                }
            }
            return false;
        }
    }
    
    // Method simpan yang dipindahkan ke dalam class
    public boolean simpan() {
        Connection conn = null;
        PreparedStatement st;
        
        try {
            conn = DbConnection.connect();
            // Simpan data detail transaksi
            String sql = "INSERT INTO salesd (salesId,barangId,qty,harga) values (?,?,?,?)";
            st = conn.prepareStatement(sql);
            st.setString(1, salesId);
            st.setString(2, barangId);
            st.setInt(3, qty);
            st.setInt(4, harga);
            st.executeUpdate();
            
            // Kurangi stok barang
            Barang barang = new Barang();
            if (barang.baca(barangId)) {
                int sisaStok = barang.getStok() - qty;
                barang.setStok(sisaStok);
                barang.updateStok();
            }
            
            conn.close(); // Pastikan connection ditutup
            return true;
        } catch (Exception e) {
            System.out.println("Gagal simpan sales detail: " + e.getMessage());
            if (conn != null) {
                try {
                    conn.close();
                } catch (Exception ex) {
                    // Log error
                }
            }
            return false;
        }
    }
}