/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tokoatk;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
/**
 *
 * @author F.Nurhayati
 */

public class Sales {
    public String id;
    public String tanggal;
    public String username;

    public boolean tambah(String username) {
        try (Connection conn = DbConnection.connect()) {
            this.username = username;
            this.id = String.valueOf(System.currentTimeMillis());
            this.tanggal = new java.text.SimpleDateFormat("yyyy-MM-dd").format(new java.util.Date());
            String sql = "INSERT INTO sales (id,tanggal,username) values (?,?,?)";
            PreparedStatement st = conn.prepareStatement(sql);
            st.setString(1, id);
            st.setString(2, tanggal);
            st.setString(3, username);
            st.executeUpdate();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public boolean addDetail(String barangId, Integer qty, Integer harga) {
        SalesDetail detail = new SalesDetail();
        detail.salesId = this.id;
        detail.barangId = barangId;
        detail.qty = qty;
        detail.harga = harga;
        return detail.simpan(); // Ganti dari tambah() ke simpan()
    }

    public boolean hapus() {
        try (Connection conn = DbConnection.connect()) {
            String sql = "DELETE FROM sales WHERE id=?";
            PreparedStatement st = conn.prepareStatement(sql);
            st.setString(1, id);
            st.executeUpdate();
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public boolean baca(String id) {
        try (Connection conn = DbConnection.connect()) {
            String sql = "SELECT * FROM sales WHERE id=?";
            PreparedStatement st = conn.prepareStatement(sql);
            st.setString(1, id);
            ResultSet rs = st.executeQuery();
            if (rs.next()) {
                this.id = rs.getString("id");
                this.tanggal = rs.getString("tanggal");
                this.username = rs.getString("username");
                return true;
            }
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    public ArrayList<SalesDetail> getDetail() {
        ArrayList<SalesDetail> list = new ArrayList<>();
        try (Connection conn = DbConnection.connect()) {
            String sql = "SELECT id FROM salesd WHERE salesId=?";
            PreparedStatement st = conn.prepareStatement(sql);
            st.setString(1, id);
            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                SalesDetail detail = new SalesDetail();
                detail.baca(rs.getInt("id"));
                list.add(detail);
            }
        } catch (Exception e) {
            // log error
        }
        return list;
    }
}
