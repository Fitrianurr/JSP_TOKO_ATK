package tokoatk;

import java.sql.*;
import java.util.ArrayList;

public class Barang {
    public String id;
    public String nama;
    public String jenis;
    public Integer harga;
    public Integer stock;

    public boolean baca(String id) {
    Connection conn = null;
    PreparedStatement st;
    ResultSet rs;

    try {
        System.out.println("Mencoba cari barang ID = " + id);
        conn = DbConnection.connect();
        String sql = "SELECT * from barang where id=?";
        st = conn.prepareStatement(sql);
        st.setString(1, id);
        rs = st.executeQuery();

        if (rs.next()) {
            System.out.println("Barang ditemukan!");
            this.id = rs.getString("id");
            this.nama = rs.getString("nama");
            this.jenis = rs.getString("jenis");
            this.harga = rs.getInt("harga");
            
            // Ganti: this.stock = rs.getInt("stock");
            // Jadi: Hitung berdasarkan transaksi masuk - keluar
            this.stock = hitungStok();

            conn.close();
            return true;
        }

        System.out.println("Barang TIDAK ditemukan.");
        conn.close();
        return false;
    } catch (Exception ex) {
        ex.printStackTrace();
        return false;
    }
}


    public String getId() {
        return id;
    }

    public String getNama() {
        return nama;
    }

    public String getJenis() {
        return jenis;
    }

    public Integer getHarga() {
        return harga;
    }

    public Integer getStok() {
        return stock;
    }

    public void setStok(int stok) {
        this.stock = stok;
    }

    public boolean update() {
        Connection conn = null;
        PreparedStatement st;

        try {
            conn = DbConnection.connect();
            String sql = "UPDATE barang SET nama=?, jenis=?, harga=?, stock=? WHERE id=?";  // ✅ stock ikut diupdate
            st = conn.prepareStatement(sql);
            st.setString(1, this.nama);
            st.setString(2, this.jenis);
            st.setInt(3, this.harga);
            st.setInt(4, this.stock);
            st.setString(5, this.id);
            st.executeUpdate();
            conn.close();
            return true;
        } catch (Exception ex) {
            return false;
        }
    }

    public boolean updateStok() {
        try {
            Connection conn = DbConnection.connect();
            String sql = "UPDATE barang SET stock = ? WHERE id = ?";
            PreparedStatement st = conn.prepareStatement(sql);
            st.setInt(1, stock);
            st.setString(2, id);
            st.executeUpdate();
            conn.close();
            return true;
        } catch (Exception e) {
            System.out.println("Gagal update stok: " + e.getMessage());
            return false;
        }
    }

    public boolean hapus() {
    try {
        Connection conn = DbConnection.connect();

        // ✅ Hapus dari relasi dulu kalau perlu (jika ON DELETE CASCADE tidak aktif)
        PreparedStatement st1 = conn.prepareStatement("DELETE FROM stockd WHERE barangId=?");
        st1.setString(1, id);
        st1.executeUpdate();
        st1.close();

        PreparedStatement st2 = conn.prepareStatement("DELETE FROM salesd WHERE barangId=?");
        st2.setString(1, id);
        st2.executeUpdate();
        st2.close();

        // 🔥 Hapus data barang
        PreparedStatement st = conn.prepareStatement("DELETE FROM barang WHERE id=?");
        st.setString(1, id);
        int rows = st.executeUpdate();

        conn.close();
        return rows > 0;
    } catch (Exception ex) {
        ex.printStackTrace(); // Wajib debug
        return false;
    }
}


    public boolean tambah() {
    try {
        Connection conn = DbConnection.connect();
        PreparedStatement st = conn.prepareStatement("INSERT INTO barang (id, nama, jenis, harga) VALUES (?, ?, ?, ?)");
        st.setString(1, this.id);
        st.setString(2, this.nama);
        st.setString(3, this.jenis);
        st.setInt(4, this.harga);
        int rows = st.executeUpdate();
        conn.close();
        return rows > 0;
    } catch (Exception e) {
        e.printStackTrace(); // << Ini WAJIB ada untuk debug!
        return false;
    }
}


    public static ArrayList<Barang> getList() {
        Connection conn = null;
        PreparedStatement st;
        ResultSet rs;
        ArrayList<Barang> result = new ArrayList<Barang>();

        try {
            conn = DbConnection.connect();
            String sql = "SELECT * from barang";
            st = conn.prepareStatement(sql);
            rs = st.executeQuery();

            while (rs.next()) {
                Barang entry = new Barang();
                entry.baca(rs.getString("id"));
                result.add(entry);
            }

            conn.close();
            return result;
        } catch (Exception ex) {
            return null;
        }
    }
    
    public static Barang getById(String id) {
    Barang b = new Barang();
    boolean ditemukan = b.baca(id); // pastikan kamu sudah punya method baca(String)
    return ditemukan ? b : null;
}

    
    public int hitungStok() {
    int masuk = 0, keluar = 0;
    try {
        Connection conn = DbConnection.connect();

        // Total masuk (stockd)
        PreparedStatement st = conn.prepareStatement("SELECT SUM(qty) AS total FROM stockd WHERE barangId = ?");
        st.setString(1, this.id);
        ResultSet rs = st.executeQuery();
        if (rs.next()) masuk = rs.getInt("total");

        // Total keluar (salesd)
        st = conn.prepareStatement("SELECT SUM(qty) AS total FROM salesd WHERE barangId = ?");
        st.setString(1, this.id);
        rs = st.executeQuery();
        if (rs.next()) keluar = rs.getInt("total");

        conn.close();
    } catch (Exception e) {
        e.printStackTrace();
    }
    return masuk - keluar;
}
}
